package com.example.dimitriusfernandes.listatarefasfinal;

import com.raizlabs.android.dbflow.annotation.Database;

/**
 * Created by Dimitrius Fernandes on 03/05/2016.
 */
@Database(name = TaskDatabase.NAME, version = TaskDatabase.VERSION)
public class TaskDatabase {

    public static final String NAME = "task_list";

    public static final int VERSION = 1;

}
