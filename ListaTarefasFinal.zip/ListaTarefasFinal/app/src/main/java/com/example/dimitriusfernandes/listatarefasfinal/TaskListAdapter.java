package com.example.dimitriusfernandes.listatarefasfinal;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by Dimitrius Fernandes on 03/05/2016.
 */
public class TaskListAdapter extends RecyclerView.Adapter<TaskListAdapter.TaskListViewHolder> {

    Context context;
    List<Task> tasks;

    public TaskListAdapter(Context context, List<Task> tasks){
        this.context = context;
        this.tasks = tasks;
    }

    @Override
    public TaskListViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        return new TaskListViewHolder(inflater.inflate(R.layout.list_tarefas, parent, false));
    }

    @Override
    public void onBindViewHolder(TaskListViewHolder holder, int position){
        if (tasks.size() > 0) {
            Task task = tasks.get(position);
            holder.format(task);
        }
    }

    @Override
    public int getItemCount(){
        return tasks == null? 0 : tasks.size();
    }

    public class TaskListViewHolder extends RecyclerView.ViewHolder {

        @Bind(R.id.name_task_text_view)
        TextView nameTaskTextView;
        @Bind(R.id.description_task_text_view)
        TextView descriptionTextView;
        @Bind(R.id.linear_layout_content1)
        LinearLayout contentLinearLayout;
        @Bind(R.id.status_task_text_view)
        TextView statusTask;

        public TaskListViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
        }

        public void format(final Task task) {
            if(task !=  null){
                nameTaskTextView.setText(task.taskName);
                descriptionTextView.setText(task.taskDescription);
                contentLinearLayout.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (task.statusTask) {
                            task.statusTask = false;
                            Toast.makeText(context, "Realizada tarefa " + task.taskName, Toast.LENGTH_SHORT).show();
                        } else {
                            task.statusTask = true;
                            Toast.makeText(context, "À realizar tarefa " + task.taskName, Toast.LENGTH_SHORT).show();
                        }
                        verificarStatusDaTask(task);
                        return false;
                    }
                });
                verificarStatusDaTask(task);
            }
        }

        public  void verificarStatusDaTask(Task task){
            if(task.statusTask){
                statusTask.setText("Tarefa Realizada");

            }else{
                statusTask.setText("Tarefa nao realizada");
            }
        }

    }
}
