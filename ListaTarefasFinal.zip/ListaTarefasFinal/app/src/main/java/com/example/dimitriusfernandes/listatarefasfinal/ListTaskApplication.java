package com.example.dimitriusfernandes.listatarefasfinal;

import android.app.Application;

import com.raizlabs.android.dbflow.config.FlowManager;

/**
 * Created by Dimitrius Fernandes on 03/05/2016.
 */
public class ListTaskApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        FlowManager.init(this);
    }
}
