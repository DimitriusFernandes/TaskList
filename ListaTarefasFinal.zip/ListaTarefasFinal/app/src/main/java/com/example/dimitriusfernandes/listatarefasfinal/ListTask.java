package com.example.dimitriusfernandes.listatarefasfinal;

import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.List;

/**
 * Created by Dimitrius Fernandes on 02/05/2016.
 */
@Table(name = "task_list_table", database = ListDatabase.class)
public class ListTask extends BaseModel {

    @PrimaryKey(autoincrement = true)
    @Column(name = "id")
    public int id;

    @Column(name = "name")
    public String name;

    public static List<ListTask> getAllLists(){
        List<ListTask> lists;
        lists = SQLite.select()
                .from(ListTask.class)
                .queryList();
        return lists;
    }
}
