package com.example.dimitriusfernandes.listatarefasfinal;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Dimitrius Fernandes on 03/05/2016.
 */
public class RegisterTaskActivity extends AppCompatActivity {

    @Bind(R.id.name_task_edit_text)
    EditText nameEditText;
    @Bind(R.id.description_task_edit_text)
    EditText descriptionEditText;
    int listId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_task_activity);
        ButterKnife.bind(this);
        listId = getIntent().getIntExtra("listId", 0);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @OnClick(R.id.save_button)
    public void save(){
        if(nameEditText.getText().toString().isEmpty() || descriptionEditText.toString().isEmpty()) {
            Toast.makeText(this,"Campo Vazio",Toast.LENGTH_SHORT).show();
        }else{
            Task task = new Task();
            task.taskName = nameEditText.getText().toString();
            task.taskDescription = descriptionEditText.getText().toString();
            task.listId = this.listId;
            task.save();
            setResult(RESULT_OK);
            finish();
        }
    }
}
