package com.example.dimitriusfernandes.listatarefasfinal;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by Dimitrius Fernandes on 02/05/2016.
 */
public class ListTaskAdapter extends RecyclerView.Adapter<ListTaskAdapter.ListTaskViewHolder> {

    Context context;
    List<ListTask> listListas;

    public ListTaskAdapter(Context context, List<ListTask> listListas) {
        this.context = context;
        this.listListas = listListas;
    }

    @Override
    public ListTaskViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        return new ListTaskViewHolder(inflater.inflate(R.layout.list_listas, parent, false));
    }

    @Override
    public void onBindViewHolder(ListTaskViewHolder holder, int position) {
        if (listListas.size() > 0) {
            ListTask list = listListas.get(position);
            holder.formater(list);
        }
    }

    @Override
    public int getItemCount() {
        return listListas == null ? 0 : listListas.size();
    }

    public class ListTaskViewHolder extends RecyclerView.ViewHolder {

        @Bind(R.id.name_list_text_view)
        TextView nameListTextView;
        @Bind(R.id.linear_layout_content)
        LinearLayout contentLinearLayout;

        public ListTaskViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }

        public void formater(final ListTask lista) {
            if (lista != null) {
                nameListTextView.setText(lista.name);
                contentLinearLayout.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        return false;
                    }
                });
                contentLinearLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(context,TaskListActivity.class);
                        intent.putExtra("listId",lista.id);
                        context.startActivity(intent);
                    }
                });
            }

        }
    }
}


