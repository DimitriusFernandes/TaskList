package com.example.dimitriusfernandes.listatarefasfinal;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @Bind(R.id.recycler_view_list)
    RecyclerView recyclerView;
    List<ListTask> listLists;
    EditText coloqueNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity);
        ButterKnife.bind(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        refreshList();
    }

    public void refreshList() {
        listLists = ListTask.getAllLists();
        if (listLists.size() > 0) {
            ListTaskAdapter adapterList = new ListTaskAdapter(this, listLists);
            recyclerView.setAdapter(adapterList);
        }
    }

    @OnClick(R.id.floating_button_new_list)
    public void createNewList(){
        AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
        alerta.setTitle("Digite o nome da lista");
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_register_list, null);
        coloqueNome = (EditText) view.findViewById(R.id.name_list_edit_text);
        alerta.setView(view);
        alerta.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ListTask listaTarefas = new ListTask();
                listaTarefas.name = coloqueNome.getText().toString();
                listaTarefas.save();
                refreshList();
            }
        });
        alerta.show();
    }
}