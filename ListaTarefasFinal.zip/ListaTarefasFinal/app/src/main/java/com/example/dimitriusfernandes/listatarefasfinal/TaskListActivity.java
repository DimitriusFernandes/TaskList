package com.example.dimitriusfernandes.listatarefasfinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by Dimitrius Fernandes on 03/05/2016.
 */
public class TaskListActivity extends AppCompatActivity {

    @Bind(R.id.recycler_view_tasks)
    RecyclerView recyclerView;
    List<Task> listTasks;
    int listId;


    public static final int REQUEST_CODE = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_task_activity);
        ButterKnife.bind(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listId = getIntent().getIntExtra("listId", 0);
        refreshList();
        if(getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK){
            refreshList();
        }
    }

    public void refreshList(){
        listTasks = Task.getTasksPeloID(listId);
        if(listTasks.size() > 0){
            TaskListAdapter adapterTask = new TaskListAdapter(this,listTasks);
            recyclerView.setAdapter(adapterTask);
        }
    }

    @OnClick(R.id.floating_button_new_task)
    public void openRegisterTaskActivity(){
        Intent intent = new Intent(this,RegisterTaskActivity.class);
        intent.putExtra("listId", listId);
        this.startActivityForResult(intent, REQUEST_CODE);
    }
}
