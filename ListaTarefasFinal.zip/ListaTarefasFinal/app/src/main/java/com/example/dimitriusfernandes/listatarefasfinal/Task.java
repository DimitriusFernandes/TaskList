package com.example.dimitriusfernandes.listatarefasfinal;

import com.raizlabs.android.dbflow.annotation.Column;
import com.raizlabs.android.dbflow.annotation.PrimaryKey;
import com.raizlabs.android.dbflow.annotation.Table;
import com.raizlabs.android.dbflow.sql.language.SQLite;
import com.raizlabs.android.dbflow.structure.BaseModel;

import java.util.List;

/**
 * Created by Dimitrius Fernandes on 03/05/2016.
 */
@Table(name = "task_table",database = TaskDatabase.class)
public class Task extends BaseModel {

    @PrimaryKey(autoincrement = true)
    @Column(name = "id")
    public int id;

    @Column(name = "taskName")
    public String taskName;

    @Column(name = "taskDescription")
    public String taskDescription;

    @Column(name = "status")
    public boolean statusTask;

    @Column(name = "listId")
    public int listId;

    public static List<Task> getAllTasks(){
        List<Task> tasks;
        tasks = SQLite.select()
                .from(Task.class)
                .queryList();
        return tasks;
    }
    public static List<Task> getTasksPeloID(int listId) {
        List<Task> tasks;
        tasks = SQLite.select()
                .from(Task.class)
                .where(Task_Table.listId.eq(listId))
                .queryList();
        return tasks;
    }
}
