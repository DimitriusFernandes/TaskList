package com.example.dimitriusfernandes.listatarefasfinal;

import com.raizlabs.android.dbflow.annotation.Database;

/**
 * Created by Dimitrius Fernandes on 02/05/2016.
 */
@Database(name = ListDatabase.NAME, version = ListDatabase.VERSION)
public class ListDatabase {

    public static final String NAME = "list_list";

    public static final int VERSION = 1;
}
